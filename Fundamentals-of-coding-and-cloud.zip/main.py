def Hello_World():
  print("Hello world")

Hello_World()
